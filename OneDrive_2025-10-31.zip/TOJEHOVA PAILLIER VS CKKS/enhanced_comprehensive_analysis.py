#!/usr/bin/env python3
"""
Enhanced Comprehensive Results Analysis for Privacy-Preserving Geofencing
Analyzes ALL performance metrics from both Paillier and CKKS implementations
Generates separate visualizations and comprehensive comparison tables
"""

import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import statistics
from collections import defaultdict
import json

class EnhancedGeofencingAnalyzer:
    def __init__(self):
        self.paillier_data = {}
        self.ckks_data = {}
        self.comparison_results = {}
        self.all_scales = ['10', '100', '500', '1000']
        
    def load_data(self, base_path):
        """Load all CSV result files from both schemes"""
        base_path = Path(base_path)
        
        # Load Paillier results - note that Paillier doesn't have 10_requests_results.csv
        paillier_files = {
            '100': base_path / 'PAILLIER' / '100_requests_results.csv',
            '500': base_path / 'PAILLIER' / '500_requests_results.csv', 
            '1000': base_path / 'PAILLIER' / '1000_requests_results.csv'
        }
        
        # Check if Paillier has 10 requests data in results.csv or other file
        paillier_10_file = base_path / 'PAILLIER' / 'results.csv'
        if paillier_10_file.exists():
            # Load and check if it contains 10 request data
            try:
                df_test = pd.read_csv(paillier_10_file)
                if len(df_test) > 0:
                    paillier_files['10'] = paillier_10_file
            except:
                pass
        
        # Load CKKS results
        ckks_files = {
            '10': base_path / 'CKKS' / '10_results_ckks.csv',
            '100': base_path / 'CKKS' / '100_results_ckks.csv',
            '500': base_path / 'CKKS' / '500_results_ckks.csv',
            '1000': base_path / 'CKKS' / '1000_results_ckks.csv'
        }
        
        # Load Paillier data
        for load_size, file_path in paillier_files.items():
            if file_path.exists():
                self.paillier_data[load_size] = pd.read_csv(file_path)
                print(f"Loaded Paillier {load_size} requests: {len(self.paillier_data[load_size])} records")
        
        # Load CKKS data  
        for load_size, file_path in ckks_files.items():
            if file_path.exists():
                self.ckks_data[load_size] = pd.read_csv(file_path)
                print(f"Loaded CKKS {load_size} requests: {len(self.ckks_data[load_size])} records")
    
    def calculate_enhanced_metrics(self, df):
        """Calculate comprehensive metrics from dataframe with proper type conversion"""
        metrics = {}
        
        # Convert string columns to appropriate types
        df = df.copy()
        df['correct'] = df['correct'].astype(bool)
        df['total_time'] = pd.to_numeric(df['total_time'], errors='coerce')
        df['encryption_time'] = pd.to_numeric(df['encryption_time'], errors='coerce')
        if 'decryption_time' in df.columns:
            df['decryption_time'] = pd.to_numeric(df['decryption_time'], errors='coerce')
        if 'ciphertext_size' in df.columns:
            df['ciphertext_size'] = pd.to_numeric(df['ciphertext_size'], errors='coerce')
        if 'payload_size' in df.columns:
            df['payload_size'] = pd.to_numeric(df['payload_size'], errors='coerce')
        
        # Basic counts
        total_requests = len(df)
        correct_predictions = df['correct'].sum()
        
        # Correctness Metrics
        metrics['accuracy'] = correct_predictions / total_requests if total_requests > 0 else 0
        
        # Calculate precision, recall, F1 for "inside" predictions
        true_inside = df[df['plaintext_decision'] == 'inside']
        pred_inside = df[df['encrypted_decision'] == 'inside']
        
        if len(df) > 0:
            true_positives = len(df[(df['plaintext_decision'] == 'inside') & (df['encrypted_decision'] == 'inside')])
            false_positives = len(df[(df['plaintext_decision'] == 'outside') & (df['encrypted_decision'] == 'inside')])
            false_negatives = len(df[(df['plaintext_decision'] == 'inside') & (df['encrypted_decision'] == 'outside')])
            
            metrics['precision'] = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
            metrics['recall'] = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
            metrics['f1_score'] = 2 * (metrics['precision'] * metrics['recall']) / (metrics['precision'] + metrics['recall']) if (metrics['precision'] + metrics['recall']) > 0 else 0
        else:
            metrics['precision'] = metrics['recall'] = metrics['f1_score'] = 0
        
        # Performance Metrics
        metrics['avg_total_time'] = df['total_time'].mean()
        metrics['std_total_time'] = df['total_time'].std()
        metrics['median_total_time'] = df['total_time'].median()
        metrics['min_total_time'] = df['total_time'].min()
        metrics['max_total_time'] = df['total_time'].max()
        
        metrics['avg_encryption_time'] = df['encryption_time'].mean()
        metrics['std_encryption_time'] = df['encryption_time'].std()
        
        if 'decryption_time' in df.columns:
            metrics['avg_decryption_time'] = df['decryption_time'].mean()
            metrics['std_decryption_time'] = df['decryption_time'].std()
        
        # Calculate throughput (requests/second)
        total_time_sum = df['total_time'].sum()
        metrics['throughput'] = total_requests / total_time_sum if total_time_sum > 0 else 0
        
        # Resource Utilization Metrics
        if 'cpu_end' in df.columns and 'cpu_start' in df.columns:
            cpu_usage = df['cpu_end'] - df['cpu_start']
            metrics['avg_cpu_usage'] = cpu_usage.mean()
            metrics['std_cpu_usage'] = cpu_usage.std()
            metrics['max_cpu_usage'] = cpu_usage.max()
        
        if 'ram_end' in df.columns and 'ram_start' in df.columns:
            ram_usage = df['ram_end'] - df['ram_start']
            metrics['avg_ram_usage'] = ram_usage.mean()
            metrics['std_ram_usage'] = ram_usage.std()
            metrics['max_ram_usage'] = ram_usage.max()
        
        # Communication Cost Metrics
        if 'ciphertext_size' in df.columns:
            metrics['avg_ciphertext_size'] = df['ciphertext_size'].mean()
            metrics['std_ciphertext_size'] = df['ciphertext_size'].std()
            metrics['total_ciphertext_size'] = df['ciphertext_size'].sum()
        
        if 'payload_size' in df.columns:
            metrics['avg_payload_size'] = df['payload_size'].mean()
            metrics['std_payload_size'] = df['payload_size'].std()
            metrics['total_payload_size'] = df['payload_size'].sum()
        
        return metrics
    
    def analyze_all_data(self):
        """Analyze all loaded data and generate comprehensive metrics"""
        results = {
            'paillier': {},
            'ckks': {}
        }
        
        # Analyze Paillier data
        for load_size, df in self.paillier_data.items():
            results['paillier'][load_size] = self.calculate_enhanced_metrics(df)
            print(f"Analyzed Paillier {load_size} requests")
        
        # Analyze CKKS data
        for load_size, df in self.ckks_data.items():
            results['ckks'][load_size] = self.calculate_enhanced_metrics(df)
            print(f"Analyzed CKKS {load_size} requests")
        
        self.comparison_results = results
        return results
    
    def create_individual_charts(self, output_dir):
        """Create separate charts for each metric"""
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
        
        # Set style for academic papers
        plt.style.use('default')
        sns.set_palette("husl")
        
        # Get common scales for both schemes
        common_scales = []
        paillier_scales = list(self.comparison_results['paillier'].keys())
        ckks_scales = list(self.comparison_results['ckks'].keys())
        
        for scale in self.all_scales:
            if scale in paillier_scales and scale in ckks_scales:
                common_scales.append(scale)
        
        load_sizes = [int(scale) for scale in common_scales]
        
        # 1. Latency Comparison Chart
        paillier_latencies = [self.comparison_results['paillier'][scale]['avg_total_time'] for scale in common_scales]
        ckks_latencies = [self.comparison_results['ckks'][scale]['avg_total_time'] for scale in common_scales]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        x = np.arange(len(load_sizes))
        width = 0.35
        
        bars1 = ax.bar(x - width/2, paillier_latencies, width, label='Paillier', alpha=0.8, color='#FF6B6B')
        bars2 = ax.bar(x + width/2, ckks_latencies, width, label='CKKS', alpha=0.8, color='#4ECDC4')
        
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Average Latency (seconds)', fontsize=14)
        ax.set_title('Performance Comparison: Average Latency by Load Size', fontsize=16, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        
        # Add value labels on bars
        for bar in bars1:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                   f'{height:.2f}s', ha='center', va='bottom', fontsize=10)
        for bar in bars2:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                   f'{height:.2f}s', ha='center', va='bottom', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'latency_comparison_detailed.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. Throughput Comparison Chart
        paillier_throughput = [self.comparison_results['paillier'][scale]['throughput'] for scale in common_scales]
        ckks_throughput = [self.comparison_results['ckks'][scale]['throughput'] for scale in common_scales]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        bars1 = ax.bar(x - width/2, paillier_throughput, width, label='Paillier', alpha=0.8, color='#FF6B6B')
        bars2 = ax.bar(x + width/2, ckks_throughput, width, label='CKKS', alpha=0.8, color='#4ECDC4')
        
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Throughput (requests/second)', fontsize=14)
        ax.set_title('Performance Comparison: Throughput by Load Size', fontsize=16, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        
        # Add value labels
        for bar in bars1:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                   f'{height:.2f}', ha='center', va='bottom', fontsize=10)
        for bar in bars2:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                   f'{height:.2f}', ha='center', va='bottom', fontsize=10)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'throughput_comparison_detailed.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. CPU Usage Comparison
        paillier_cpu = [self.comparison_results['paillier'][scale].get('avg_cpu_usage', 0) for scale in common_scales]
        ckks_cpu = [self.comparison_results['ckks'][scale].get('avg_cpu_usage', 0) for scale in common_scales]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        bars1 = ax.bar(x - width/2, paillier_cpu, width, label='Paillier', alpha=0.8, color='#FF6B6B')
        bars2 = ax.bar(x + width/2, ckks_cpu, width, label='CKKS', alpha=0.8, color='#4ECDC4')
        
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Average CPU Usage (%)', fontsize=14)
        ax.set_title('Resource Utilization: CPU Usage Comparison', fontsize=16, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'cpu_usage_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 4. RAM Usage Comparison
        paillier_ram = [self.comparison_results['paillier'][scale].get('avg_ram_usage', 0) for scale in common_scales]
        ckks_ram = [self.comparison_results['ckks'][scale].get('avg_ram_usage', 0) for scale in common_scales]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        bars1 = ax.bar(x - width/2, paillier_ram, width, label='Paillier', alpha=0.8, color='#FF6B6B')
        bars2 = ax.bar(x + width/2, ckks_ram, width, label='CKKS', alpha=0.8, color='#4ECDC4')
        
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Average RAM Usage (MB)', fontsize=14)
        ax.set_title('Resource Utilization: Memory Usage Comparison', fontsize=16, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'ram_usage_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 5. Ciphertext Size Comparison
        paillier_sizes = [self.comparison_results['paillier'][scale].get('avg_ciphertext_size', 0) for scale in common_scales]
        ckks_sizes = [self.comparison_results['ckks'][scale].get('avg_ciphertext_size', 0) for scale in common_scales]
        
        fig, ax = plt.subplots(figsize=(12, 8))
        bars1 = ax.bar(x - width/2, paillier_sizes, width, label='Paillier', alpha=0.8, color='#FF6B6B')
        bars2 = ax.bar(x + width/2, ckks_sizes, width, label='CKKS', alpha=0.8, color='#4ECDC4')
        
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Average Ciphertext Size (bytes)', fontsize=14)
        ax.set_title('Communication Cost: Ciphertext Size Comparison', fontsize=16, fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'ciphertext_size_comparison_detailed.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 6. Scalability Trends (Line Charts)
        fig, ax = plt.subplots(figsize=(12, 8))
        ax.plot(load_sizes, paillier_latencies, 'o-', label='Paillier', linewidth=3, markersize=10, color='#FF6B6B')
        ax.plot(load_sizes, ckks_latencies, 's-', label='CKKS', linewidth=3, markersize=10, color='#4ECDC4')
        ax.set_xlabel('Number of Requests', fontsize=14)
        ax.set_ylabel('Average Latency (seconds)', fontsize=14)
        ax.set_title('Scalability Analysis: Latency Trends Across Load Sizes', fontsize=16, fontweight='bold')
        ax.legend(fontsize=12)
        ax.grid(True, alpha=0.3)
        ax.set_yscale('log')  # Log scale to better show the dramatic difference
        
        plt.tight_layout()
        plt.savefig(output_dir / 'scalability_latency_trends.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Individual charts saved to {output_dir}")
    
    def generate_comprehensive_tables(self):
        """Generate all comparison tables for academic presentation"""
        
        # Get all available scales for both schemes
        paillier_scales = sorted(self.comparison_results['paillier'].keys(), key=int)
        ckks_scales = sorted(self.comparison_results['ckks'].keys(), key=int)
        all_scales = sorted(list(set(paillier_scales + ckks_scales)), key=int)
        
        # 1. Performance Comparison Table
        perf_table = []
        
        for scale in all_scales:
            row = {'Load Size': f"{scale} requests"}
            
            # Paillier metrics
            if scale in self.comparison_results['paillier']:
                paillier_metrics = self.comparison_results['paillier'][scale]
                row['Paillier Latency (s)'] = f"{paillier_metrics['avg_total_time']:.4f}"
                row['Paillier Std Dev (s)'] = f"{paillier_metrics.get('std_total_time', 0):.4f}"
                row['Paillier Throughput (req/s)'] = f"{paillier_metrics['throughput']:.4f}"
                row['Paillier Accuracy (%)'] = f"{paillier_metrics['accuracy']*100:.2f}"
            else:
                row['Paillier Latency (s)'] = "N/A"
                row['Paillier Std Dev (s)'] = "N/A"
                row['Paillier Throughput (req/s)'] = "N/A"
                row['Paillier Accuracy (%)'] = "N/A"
            
            # CKKS metrics
            if scale in self.comparison_results['ckks']:
                ckks_metrics = self.comparison_results['ckks'][scale]
                row['CKKS Latency (s)'] = f"{ckks_metrics['avg_total_time']:.4f}"
                row['CKKS Std Dev (s)'] = f"{ckks_metrics.get('std_total_time', 0):.4f}"
                row['CKKS Throughput (req/s)'] = f"{ckks_metrics['throughput']:.4f}"
                row['CKKS Accuracy (%)'] = f"{ckks_metrics['accuracy']*100:.2f}"
                
                # Calculate improvements if both are available
                if scale in self.comparison_results['paillier']:
                    latency_improvement = ((paillier_metrics['avg_total_time'] - ckks_metrics['avg_total_time']) / paillier_metrics['avg_total_time']) * 100
                    throughput_improvement = ((ckks_metrics['throughput'] - paillier_metrics['throughput']) / paillier_metrics['throughput']) * 100 if paillier_metrics['throughput'] > 0 else float('inf')
                    row['Latency Improvement (%)'] = f"{latency_improvement:.2f}"
                    row['Throughput Improvement (%)'] = f"{throughput_improvement:.2f}" if throughput_improvement != float('inf') else ">100,000"
                else:
                    row['Latency Improvement (%)'] = "N/A"
                    row['Throughput Improvement (%)'] = "N/A"
            else:
                row['CKKS Latency (s)'] = "N/A"
                row['CKKS Std Dev (s)'] = "N/A"
                row['CKKS Throughput (req/s)'] = "N/A"
                row['CKKS Accuracy (%)'] = "N/A"
                row['Latency Improvement (%)'] = "N/A"
                row['Throughput Improvement (%)'] = "N/A"
            
            perf_table.append(row)
        
        # 2. Resource Utilization Table
        resource_table = []
        for scale in all_scales:
            row = {'Load Size': f"{scale} requests"}
            
            if scale in self.comparison_results['paillier']:
                paillier_metrics = self.comparison_results['paillier'][scale]
                row['Paillier CPU (%)'] = f"{paillier_metrics.get('avg_cpu_usage', 0):.2f}"
                row['Paillier RAM (MB)'] = f"{paillier_metrics.get('avg_ram_usage', 0):.2f}"
                row['Paillier Ciphertext (bytes)'] = f"{paillier_metrics.get('avg_ciphertext_size', 0):.0f}"
                row['Paillier Payload (bytes)'] = f"{paillier_metrics.get('avg_payload_size', 0):.0f}"
            else:
                row['Paillier CPU (%)'] = "N/A"
                row['Paillier RAM (MB)'] = "N/A"
                row['Paillier Ciphertext (bytes)'] = "N/A"
                row['Paillier Payload (bytes)'] = "N/A"
            
            if scale in self.comparison_results['ckks']:
                ckks_metrics = self.comparison_results['ckks'][scale]
                row['CKKS CPU (%)'] = f"{ckks_metrics.get('avg_cpu_usage', 0):.2f}"
                row['CKKS RAM (MB)'] = f"{ckks_metrics.get('avg_ram_usage', 0):.2f}"
                row['CKKS Ciphertext (bytes)'] = f"{ckks_metrics.get('avg_ciphertext_size', 0):.0f}"
                row['CKKS Payload (bytes)'] = f"{ckks_metrics.get('avg_payload_size', 0):.0f}"
                
                # Calculate size ratios
                if scale in self.comparison_results['paillier'] and paillier_metrics.get('avg_ciphertext_size', 0) > 0:
                    size_ratio = ckks_metrics.get('avg_ciphertext_size', 0) / paillier_metrics.get('avg_ciphertext_size', 1)
                    row['Size Ratio (CKKS/Paillier)'] = f"{size_ratio:.1f}x"
                else:
                    row['Size Ratio (CKKS/Paillier)'] = "N/A"
            else:
                row['CKKS CPU (%)'] = "N/A"
                row['CKKS RAM (MB)'] = "N/A"
                row['CKKS Ciphertext (bytes)'] = "N/A"
                row['CKKS Payload (bytes)'] = "N/A"
                row['Size Ratio (CKKS/Paillier)'] = "N/A"
            
            resource_table.append(row)
        
        # 3. Detailed Statistical Analysis Table
        stats_table = []
        for scale in all_scales:
            for scheme in ['Paillier', 'CKKS']:
                scheme_key = scheme.lower()
                if scale in self.comparison_results[scheme_key]:
                    metrics = self.comparison_results[scheme_key][scale]
                    row = {
                        'Scheme': scheme,
                        'Load Size': f"{scale} requests",
                        'Mean Latency (s)': f"{metrics['avg_total_time']:.6f}",
                        'Std Dev Latency (s)': f"{metrics.get('std_total_time', 0):.6f}",
                        'Median Latency (s)': f"{metrics.get('median_total_time', 0):.6f}",
                        'Min Latency (s)': f"{metrics.get('min_total_time', 0):.6f}",
                        'Max Latency (s)': f"{metrics.get('max_total_time', 0):.6f}",
                        'Mean Encryption (s)': f"{metrics.get('avg_encryption_time', 0):.6f}",
                        'Std Encryption (s)': f"{metrics.get('std_encryption_time', 0):.6f}",
                        'Throughput (req/s)': f"{metrics['throughput']:.4f}",
                        'Accuracy': f"{metrics['accuracy']:.4f}",
                        'Precision': f"{metrics['precision']:.4f}",
                        'Recall': f"{metrics['recall']:.4f}",
                        'F1-Score': f"{metrics['f1_score']:.4f}"
                    }
                    stats_table.append(row)
        
        return perf_table, resource_table, stats_table
    
    def export_results_tables(self, output_file):
        """Export all results tables to markdown file"""
        perf_table, resource_table, stats_table = self.generate_comprehensive_tables()
        
        with open(output_file, 'w') as f:
            f.write("# Comprehensive Results Tables\n\n")
            f.write("## Performance Comparison Table (All Scales)\n\n")
            
            # Performance table
            if perf_table:
                headers = list(perf_table[0].keys())
                f.write("| " + " | ".join(headers) + " |\n")
                f.write("|" + "|".join(["-" * (len(h)+2) for h in headers]) + "|\n")
                
                for row in perf_table:
                    f.write("| " + " | ".join([str(row.get(h, "N/A")) for h in headers]) + " |\n")
            
            f.write("\n\n## Resource Utilization Comparison (All Scales)\n\n")
            
            # Resource table
            if resource_table:
                headers = list(resource_table[0].keys())
                f.write("| " + " | ".join(headers) + " |\n")
                f.write("|" + "|".join(["-" * (len(h)+2) for h in headers]) + "|\n")
                
                for row in resource_table:
                    f.write("| " + " | ".join([str(row.get(h, "N/A")) for h in headers]) + " |\n")
            
            f.write("\n\n## Detailed Statistical Analysis (All Scales)\n\n")
            
            # Statistical table
            if stats_table:
                headers = list(stats_table[0].keys())
                f.write("| " + " | ".join(headers) + " |\n")
                f.write("|" + "|".join(["-" * (len(h)+2) for h in headers]) + "|\n")
                
                for row in stats_table:
                    f.write("| " + " | ".join([str(row.get(h, "N/A")) for h in headers]) + " |\n")
            
            # Add summary section
            f.write("\n\n## Key Findings Summary\n\n")
            f.write("### Performance Improvements (CKKS vs Paillier)\n\n")
            
            # Calculate and write key improvements for available scales
            common_scales = []
            for scale in self.all_scales:
                if (scale in self.comparison_results['paillier'] and 
                    scale in self.comparison_results['ckks']):
                    common_scales.append(scale)
            
            for scale in common_scales:
                paillier = self.comparison_results['paillier'][scale]
                ckks = self.comparison_results['ckks'][scale]
                
                latency_imp = ((paillier['avg_total_time'] - ckks['avg_total_time']) / paillier['avg_total_time']) * 100
                throughput_imp = ((ckks['throughput'] - paillier['throughput']) / paillier['throughput']) * 100 if paillier['throughput'] > 0 else float('inf')
                
                f.write(f"**{scale} Requests:**\n")
                f.write(f"- Latency Improvement: {latency_imp:.2f}%\n")
                f.write(f"- Throughput Improvement: {throughput_imp:.2f}%\n")
                f.write(f"- CKKS Latency: {ckks['avg_total_time']:.4f}s vs Paillier: {paillier['avg_total_time']:.4f}s\n")
                f.write(f"- CKKS Throughput: {ckks['throughput']:.4f} req/s vs Paillier: {paillier['throughput']:.4f} req/s\n\n")
        
        print(f"Results tables exported to {output_file}")

def main():
    analyzer = EnhancedGeofencingAnalyzer()
    base_path = r"C:\Users\nicol\Downloads\TOJEHOVA PAILLIER VS CKKS"
    
    # Load and analyze data
    analyzer.load_data(base_path)
    results = analyzer.analyze_all_data()
    
    # Create individual visualizations
    analyzer.create_individual_charts(base_path)
    
    # Export comprehensive results tables
    analyzer.export_results_tables(Path(base_path) / 'COMPREHENSIVE_RESULTS_TABLES.md')
    
    # Export detailed results JSON
    with open(Path(base_path) / 'enhanced_comprehensive_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print("\nEnhanced analysis complete!")
    print("Generated files:")
    print("- Individual charts: latency_comparison_detailed.png, throughput_comparison_detailed.png, etc.")
    print("- Comprehensive tables: COMPREHENSIVE_RESULTS_TABLES.md")
    print("- Detailed results: enhanced_comprehensive_results.json")

if __name__ == "__main__":
    main()