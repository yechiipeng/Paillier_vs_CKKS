# Complete Metrics Analysis: All Scales Comparison

## 1. Correctness Metrics (All Scales)

| Load Size | Paillier Accuracy (%) | Paillier Precision (%) | Paillier Recall (%) | Paillier F1-Score (%) | CKKS Accuracy (%) | CKKS Precision (%) | CKKS Recall (%) | CKKS F1-Score (%) |
|-----------|-----------------------|------------------------|---------------------|-----------------------|-------------------|--------------------|-----------------|-------------------|
| 10 requests | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| 100 requests | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| 500 requests | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| 1000 requests | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |

**Analysis:**
- Both schemes maintain perfect classification accuracy (100%) across all scales
- Precision, Recall, and F1-Score remain consistently at 100% for both encryption methods
- No degradation in correctness metrics with increasing load sizes
- CKKS approximations do not compromise classification accuracy

## 2. Performance Metrics (All Scales)

| Load Size | Paillier Total Runtime (s) | Paillier Avg Latency (s) | Paillier P95 Latency (s) | Paillier P99 Latency (s) | Paillier Throughput (req/s) | CKKS Total Runtime (s) | CKKS Avg Latency (s) | CKKS P95 Latency (s) | CKKS P99 Latency (s) | CKKS Throughput (req/s) | Runtime Improvement (%) | Latency Improvement (%) | Throughput Improvement (%) |
|-----------|----------------------------|--------------------------|--------------------------|--------------------------|-----------------------------|------------------------|----------------------|----------------------|----------------------|-------------------------|-------------------------|-------------------------|----------------------------|
| 10 requests | 2500.09 | 7.5760 | 13.4173 | 13.7694 | 0.1440 | 167.39 | 0.5072 | 1.0000 | 1.0000 | 1.9714 | 93.30 | 93.30 | 1269.11 |
| 100 requests | 185255.87 | 61.1406 | 114.9299 | 119.7813 | 0.0165 | 1392.41 | 0.4595 | 0.4946 | 0.5911 | 2.1761 | 99.25 | 99.25 | 13074.21 |
| 500 requests | 4424847.54 | 294.4010 | 557.3487 | 580.8291 | 0.0034 | 6865.93 | 0.4568 | 0.4943 | 0.5114 | 2.1891 | 99.84 | 99.84 | 64218.06 |
| 1000 requests | 18095679.91 | 602.5867 | 1142.4198 | 1202.5727 | 0.0017 | 13770.48 | 0.4577 | 0.4950 | 0.5118 | 2.1847 | 99.92 | 99.92 | 131414.09 |

**Analysis:**
- CKKS demonstrates 93-99% latency improvements across all scales
- Throughput improvements range from 1,269% to 131,414%
- Total runtime scales exponentially for Paillier vs. linearly for CKKS
- P95 and P99 latencies remain stable for CKKS, degrade severely for Paillier

## 3. Resource Utilization Metrics (All Scales)

| Load Size | Paillier Avg CPU (%) | Paillier Peak CPU (%) | Paillier Avg RAM (MB) | Paillier Peak RAM (MB) | CKKS Avg CPU (%) | CKKS Peak CPU (%) | CKKS Avg RAM (MB) | CKKS Peak RAM (MB) | CPU Reduction (%) |
|-----------|----------------------|-----------------------|-----------------------|------------------------|------------------|-------------------|-------------------|--------------------|-------------------|
| 10 requests | 16.57 | 30.50 | -0.05 | 0.47 | -0.17 | 8.10 | 7.89 | 10.22 | 101.0 |
| 100 requests | 22.51 | 34.30 | -0.92 | 5.03 | 0.15 | 15.40 | 8.18 | 10.47 | 99.3 |
| 500 requests | 10.81 | 35.30 | -1.88 | 50.33 | 1.13 | 30.00 | 8.15 | 10.40 | 89.6 |
| 1000 requests | 8.74 | 42.80 | -17.47 | 156.78 | 1.70 | 22.60 | 8.29 | 10.61 | 80.5 |

**Analysis:**
- CKKS shows consistent and minimal CPU utilization (<=1.7%)
- Paillier exhibits variable and higher CPU usage (8-23%)
- Peak resource usage remains predictable for CKKS
- CKKS demonstrates 81-99% CPU usage reduction compared to Paillier

## 4. Communication Cost Metrics (All Scales)

| Load Size | Paillier Ciphertext (bytes) | Paillier Total Bandwidth (MB) | Paillier Payload Efficiency (%) | CKKS Ciphertext (bytes) | CKKS Total Bandwidth (MB) | CKKS Payload Efficiency (%) | Size Ratio (CKKS/Paillier) | Bandwidth Ratio (CKKS/Paillier) |
|-----------|-----------------------------|-------------------------------|---------------------------------|-------------------------|---------------------------|-----------------------------|----------------------------|---------------------------------|
| 10 requests | 177 | 1.89 | 2.68 | 324541 | 2439.19 | 3.81 | 1833.6x | 1292.0x |
| 100 requests | 177 | 18.88 | 2.68 | 324550 | 24391.89 | 3.81 | 1833.6x | 1292.0x |
| 500 requests | 177 | 94.40 | 2.68 | 324522 | 121959.07 | 3.81 | 1833.5x | 1292.0x |
| 1000 requests | 177 | 188.80 | 2.68 | 324511 | 244356.91 | 3.81 | 1833.4x | 1294.3x |

**Analysis:**
- CKKS ciphertexts are consistently ~1,834x larger than Paillier
- Total bandwidth requirements scale proportionally with request count
- Despite larger ciphertext size, computational benefits outweigh communication costs
- Payload efficiency varies between schemes due to different encryption approaches

## 5. Scalability Metrics (All Scales)

| Load Size | Paillier Requests/Sec | Paillier Throughput Efficiency | Paillier Latency per Request (s) | CKKS Requests/Sec | CKKS Throughput Efficiency | CKKS Latency per Request (s) | Efficiency Improvement (%) |
|-----------|-----------------------|--------------------------------|----------------------------------|-------------------|----------------------------|------------------------------|----------------------------|
| 10 requests | 0.1440 | 0.000400 | 7.5760 | 1.9714 | 0.005974 | 0.5072 | 1393.57 |
| 100 requests | 0.0165 | 0.000005 | 61.1406 | 2.1761 | 0.000718 | 0.4595 | 13204.65 |
| 500 requests | 0.0034 | 0.000000 | 294.4010 | 2.1891 | 0.000146 | 0.4568 | 64346.44 |
| 1000 requests | 0.0017 | 0.000000 | 602.5867 | 2.1847 | 0.000073 | 0.4577 | 131309.17 |

**Analysis:**
- CKKS maintains stable requests/second across all concurrent user scenarios
- Throughput efficiency demonstrates CKKS's superior scalability characteristics
- Latency per request remains constant for CKKS, increases exponentially for Paillier
- Efficiency improvements exceed 100,000% for high-load scenarios

## Summary: Complete Metrics Comparison

### Key Performance Indicators (All Scales)

| **Metric Category** | **Paillier Performance** | **CKKS Performance** | **CKKS Advantage** |
|-------------------|-------------------------|---------------------|--------------------|
| **Correctness** | 100% accuracy across all scales | 100% accuracy across all scales | **Equal** |
| **Performance** | Avg latency: 241.43s | Avg latency: 0.47s | **99.8% faster** |
| **Resource Usage** | Avg CPU: 14.7% | Avg CPU: 0.7% | **95.2% less CPU** |
| **Communication** | Avg size: 177 bytes | Avg size: 324531 bytes | **1834x larger** |
| **Scalability** | Exponential degradation (O(n²)) | Linear stability (O(1)) | **Suitable for production** |
