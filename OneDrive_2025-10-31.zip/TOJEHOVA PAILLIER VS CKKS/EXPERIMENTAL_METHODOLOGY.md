# Chapter 3: Methodology

## 3. Methodology

### 3.1 Overview

This chapter outlines the methodological approach undertaken to design, implement, and evaluate a privacy-preserving circular geofencing framework. The methodology is structured around three core components: (i) the theoretical underpinnings guiding the system design, (ii) the experimental procedures adopted to establish baseline and proposed implementations, and (iii) the evaluation strategies employed to benchmark performance, security, and regulatory compliance.

### 3.2 Theoretical Framework

This study aims to optimize privacy preservation in circular geofencing by adopting a comparative experimental design between a partially homomorphic encryption baseline (Paillier), and a fully homomorphic approach (CKKS) with the goal of maintaining accuracy while reducing latency, ciphertext size, and CPU and network operational costs. The specific research objectives to be achieved are:

1. **Primary Objective**: Determine whether replacing Paillier encryption with CKKS encryption will improve performance while maintaining accuracy
2. **Secondary Objective**: Evaluate and compare the ciphertext size, resource costs, and network costs between both schemes

By implementing both schemes, the methodology allows rigorous trade-off analysis between accuracy and performance, addressing a research gap in prior works that only evaluate a single encryption scheme.

### 3.3 System Architecture

The proposed system employs a distributed microservice architecture designed to simulate real-world deployment conditions while enabling controlled experimental evaluation. Two cryptographic schemes are implemented for comparative analysis: Paillier and CKKS. Each microservice is containerized using Docker containers and communicates via HTTP by calling each other's APIs.

#### 3.3.1 System Components

This system consists of three core elements:

**User Element:**
- Fetches public keys from the key authority service
- Encrypts GPS coordinates using the designated cryptographic scheme
- Sends encrypted ciphertexts to the geofencing service
- Logs performance metrics and classification results

**Key Authority Service:**
- Produces and distributes public and evaluation keys
- Maintains secret decryption keys in secure isolation
- Performs final decryption and containment classification
- Implements threshold-based geofence evaluation

**Geofencing Service:**
- Computes encrypted intermediate distance values
- Performs homomorphic operations on encrypted coordinates
- Interfaces with external geofence data sources
- Forwards encrypted results to the key authority service

#### 3.3.2 Baseline Architecture (Paillier)

Paillier encryption is a form of partially homomorphic encryption that supports only additive operations on ciphertexts. This limitation requires iterative computations for operations involving multiplication and exponents, ultimately leading to increased ciphertext size and network traffic due to the volume of required computations.

**Mathematical Foundation:**
The Paillier cryptosystem is based on the composite residuosity problem and operates by creating a public key (n, g) and private key (λ, μ).

**Homomorphic Properties:**
- **Additively homomorphic:** E(m₁) ⊕ E(m₂) = E(m₁ + m₂)
- **Scalar multiplication:** E(m) ⊗ k = E(k × m)

These properties enable the computation of encrypted distance calculations through homomorphic addition and scalar multiplication operations.

#### 3.3.3 Proposed Architecture (CKKS)

CKKS is a fully homomorphic encryption scheme that enables both additive and multiplicative operations on ciphertext. This capability allows it to perform computations with greater multiplicative depth and significantly less noise accumulation compared to partially homomorphic schemes such as Paillier.

**SIMD Batching Implementation:**
A key advantage of CKKS is its support for batching (Single Instruction, Multiple Data), which allows multiple values to be packed into a single ciphertext and processed simultaneously using polynomial arithmetic.

**Mathematical Properties:**
- CKKS operates on polynomial rings where a single ciphertext can encode N/2 complex numbers (where N = poly_modulus_degree)
- With poly_modulus_degree=4096, up to 2048 complex values can be batched in one ciphertext
- Operations on the ciphertext perform element-wise operations on all batched values simultaneously

**Efficiency Gains:**
- **Computational**: Process N locations with the same operations as 1
- **Network**: Send 3 ciphertexts for N locations versus 3N ciphertexts in non-batched approaches
- **Storage**: Utilize the same memory footprint for N times more data

### 3.4 Mathematical Foundations

#### 3.4.1 Circular Geofencing Theory

The basis of circular geofencing relies on determining whether a location (x,y) lies inside a circular region defined by centre (xc,yc) and radius r. For two-dimensional Euclidean space, this is expressed as:

```mathematical
(x - xc)² + (y - yc)² ≤ r²
```

However, this equation is only suitable for planar coordinates. Since actual longitude and latitude values are angular coordinates on a spherical surface, they require spherical geometry for accurate distance computation.

#### 3.4.2 Haversine Formula Implementation

To accurately compute distances between GPS coordinates, the 2D circular geofence equation is expressed using the Haversine formula for two points (latu, lonu) and (latc, lonc):

```mathematical
a = sin²(Δlat/2) + cos(latu) × cos(latc) × sin²(Δlon/2)
c = 2 × atan2(√a, √(1-a))
distance = R × c
```

Where:
- R = Earth's radius (6,371,000 meters)
- Δlat = latc - latu
- Δlon = lonc - lonu

**Containment Evaluation:**
To check if the location is within the geofence:
```mathematical
distance ≤ radius
```

#### 3.4.3 Homomorphic Distance Computation

For homomorphic evaluation, user coordinates are decomposed into trigonometric components:

```mathematical
c₁ = E(sin(φᵤ))
c₂ = E(cos(φᵤ) × cos(λᵤ))  
c₃ = E(cos(φᵤ) × sin(λᵤ))
```

Where φᵤ and λᵤ represent user latitude and longitude in radians, respectively. The encrypted intermediate Haversine value is computed as:

```mathematical
h_intermediate = 1 - c₁ × sin(φ_center) - c₂ × cos(φ_center) × cos(λ_center) - c₃ × cos(φ_center) × sin(λ_center)
```

### 3.5 Evaluation Metrics

#### 3.5.1 Correctness Metrics
- **Accuracy:** Overall classification correctness compared to plaintext benchmarks
- **Precision:** True positive rate for "inside" geofence predictions  
- **Recall:** Sensitivity for detecting actual containment cases
- **F1-Score:** Harmonic mean of precision and recall

#### 3.5.2 Performance Metrics
- **Total Runtime:** Aggregate processing time for all requests in an experiment
- **Latency:** Average processing time per individual request (seconds)
- **Throughput:** Number of requests processed per unit time (requests/second)

#### 3.5.3 Resource Utilization Metrics
- **CPU Consumption:** Processor utilization per service container during operation
- **RAM Usage:** Memory consumption patterns across microservices
- **Peak Resource Usage:** Maximum resource consumption during high-load scenarios

#### 3.5.4 Communication Cost Metrics
- **Ciphertext Size:** Encrypted payload size per request (bytes)
- **Network Bandwidth:** Total data transmission requirements per containment decision
- **Payload Efficiency:** Ratio of semantic content to total transmission size

#### 3.5.5 Scalability Metrics
- **Concurrent User Simulation:** Testing with 10, 100, 500, and 1000 concurrent users via threading
- **Batch Processing Efficiency:** CKKS-specific batching performance evaluation
- **Scalability Factor:** Performance degradation analysis with increasing load

### 3.6 Dataset Specification

#### 3.6.1 Coordinate Data Processing
Data points include user latitude/longitude coordinates in radians, processed according to the following protocol:

**Paillier Scheme:**
- Coordinates broken into trigonometric components
- Individual encryption of each component
- Sequential processing of location queries

**CKKS Scheme:**
- Conversion to 3D Cartesian unit vectors
- Batched encryption enabling SIMD operations
- Parallel processing of multiple location queries

#### 3.6.2 Privacy and Regulatory Compliance
The location data does not relate to identifiable persons or objects but is classified as personal data under GDPR (Article 4, Recital 26) due to its potential for indirect identification. Accordingly:
- Only encrypted intermediate values are transmitted between services
- No raw coordinates are stored or logged
- Data minimization principles are strictly enforced

#### 3.6.3 Synthetic Data Generation
Synthetic user coordinates are systematically generated to simulate three distinct categories:
- **Inside Geofence:** Coordinates within the defined circular boundary
- **Boundary Conditions:** Coordinates precisely on the geofence perimeter  
- **Outside Geofence:** Coordinates beyond the circular boundary

This comprehensive coverage ensures robust testing of containment decisions under varied geographical conditions.

### 3.7 Implementation Environment

#### 3.7.1 Software Stack
- **Programming Language:** Python 3.10
- **Cryptographic Libraries:** 
  - Paillier: PHE (Python Homomorphic Encryption) library
  - CKKS: TenSEAL (Microsoft SEAL for Python)
- **Supporting Libraries:** math, time, threading, requests, Flask
- **Containerization:** Docker with Docker Compose orchestration
- **Web Framework:** Flask with Gunicorn WSGI server

#### 3.7.2 Hardware Specifications
- **Processor:** 1.80 GHz AMD Ryzen 7 5700U processor
- **Memory:** 8GB RAM
- **Architecture:** 64-bit operating system, x64-based processor
- **Storage:** SSD with sufficient space for experimental data logging

#### 3.7.3 Development Environment
- **Dependency Management:** requirements.txt for reproducible package versions
- **Version Control:** Git for source code management and experimental reproducibility
- **Containerization:** Docker ensures consistent deployment across different environments

### 3.8 Experimental Procedure

#### 3.8.1 Reproducibility Protocol
To ensure experimental reproducibility, system development and testing are conducted in a controlled environment with the following measures:
- **Environment Standardization:** Python 3.10 with fixed dependency versions via requirements.txt
- **Containerization:** Docker containers provide consistent runtime environments
- **Statistical Rigor:** Each experiment is repeated 30 times with results summarized using mean, median, standard deviation, and 95% confidence intervals

#### 3.8.2 Experimental Phases

The methodology consists of the following sequential experimental phases:

##### Phase 1: System Setup
Two Flask microservices are implemented and deployed:
- **Geofencing Service:** Responsible for receiving encrypted user locations and computing encrypted intermediate values of the Haversine formula
- **Key Authority Service:** Responsible for decrypting intermediate results and returning containment decisions

**Implementation Details:**
- Paillier-based services developed using the PHE library
- CKKS implementation extended using the TenSEAL library
- RESTful API design for inter-service communication
- Docker Compose orchestration for service coordination

##### Phase 2: Geofence Definition
Geofence boundaries are derived from real-world data using the OpenStreetMap Overpass API, ensuring realistic deployment conditions:
- Each geofence represented by latitude, longitude, and radius parameters
- Multiple geofences instantiated to test system scalability
- Fallback coordinates implemented for API reliability

##### Phase 3: Data Generation
Synthetic user coordinates are generated to simulate comprehensive testing scenarios:
- **Inside Category:** Locations within geofence boundaries
- **Boundary Category:** Locations precisely on geofence perimeters
- **Outside Category:** Locations beyond geofence boundaries
- Ensures comprehensive testing of containment decisions under varied conditions

##### Phase 4: Baseline System Execution (Paillier)
The Paillier implementation follows this protocol:
1. User coordinates encrypted under Paillier public key
2. Encrypted coordinates transmitted to geofencing service
3. Intermediate Haversine values computed homomorphically
4. Results transmitted to key authority service
5. Decryption and classification as "inside" or "outside"
6. Comprehensive metrics collection including ciphertext size, computation time, and classification correctness

##### Phase 5: Proposed System Execution (CKKS)
The CKKS implementation employs an enhanced pipeline:
1. GPS coordinates encrypted as floating-point numbers without fixed-point encoding
2. Polynomial approximations applied for trigonometric function computation within encrypted domain
3. Systematic parameter variation (polynomial modulus degree, scale, batch size) to balance accuracy against runtime efficiency
4. Advanced batching techniques for SIMD operations
5. Comprehensive performance evaluation including batching efficiency analysis

##### Phase 6: Benchmarking and Statistical Analysis
Rigorous statistical evaluation encompasses:
- Multiple repetitions of each containment check to account for computation and network variability
- Calculation of mean values, standard deviations, and 95% confidence intervals
- Comprehensive metric analysis covering accuracy, runtime, latency, throughput, and ciphertext size
- Direct comparative analysis between Paillier and CKKS implementations

##### Phase 7: Adversarial Simulation
Security evaluation through metadata analysis:
- Capture and analysis of ciphertext length patterns
- Transmission frequency and timing analysis
- Evaluation of susceptibility to inference attacks
- Side-channel resistance assessment

##### Phase 8: Regulatory Validation
GDPR compliance verification focusing on:
- **Data Minimization:** Verification that only necessary coordinate components are processed
- **Third-party Access Prevention:** Ensuring no raw location data exposure
- **Privacy-by-Design Principles:** Comprehensive privacy protection throughout the system lifecycle

### 3.9 Baseline Implementation Protocol

#### 3.9.1 Key Authority Service Setup
**Step 1:** Initialize Key Authority Service
- Deploy Flask application on port 5002
- Generate Paillier key pair (PaillierPublicKey, PaillierPrivateKey)
- Implement secure key storage and access control

**API Endpoints:**
- `/get_public_key` → Distributes public key (n) to authorized clients
- `/submit-geofence-result-ref` → Accepts encrypted distance values, performs decryption, and compares with r²

**Security Configuration:** 
- Threshold configuration ensures Key Authority alone cannot fully compromise privacy
- Audit logging for all key access and decryption operations

#### 3.9.2 Geofencing Service Deployment
**Step 2:** Launch Geofencing Service
- Deploy Flask application on port 5001
- Fetch geofence coordinates from OpenStreetMap/Overpass API
- Convert geofence center latitude/longitude to radians for Haversine computations

**API Endpoints:**
- `/submit-location-ref` → Receives encrypted user inputs (x-xc)², (y-yc)²
- Computes encrypted intermediate values using Paillier homomorphic addition
- Forwards encrypted results to Key Authority for decryption

#### 3.9.3 Mobile Node (Client) Implementation
**Step 3:** Client Application Development
- Implement client script with comprehensive logging capabilities
- Fetch Paillier public key from Key Authority (`/get_public_key`)
- Encode user location in radians and compute squared differences: (x-xc)², (y-yc)²
- Encrypt values using Paillier encryption
- Transmit encrypted payloads to Geofencing Service endpoint (`/submit-location-ref`)

#### 3.9.4 Correctness Evaluation Protocol
**Step 4:** Accuracy Validation
- Log all decrypted results at Key Authority service
- Compare decrypted distance results against plaintext computations: (x-xc)² + (y-yc)² ≤ r²
- Verify that Paillier-based system produces identical inside/outside classifications
- Calculate accuracy, precision, recall, and F1-score metrics

#### 3.9.5 Performance Measurement Protocol
**Step 5:** Latency Analysis
Utilize high-precision timing around critical operations:
- **Encryption Timing:** Client-side coordinate encryption
- **Transmission Timing:** Client → Geofencing → Key Authority communication
- **Decryption Timing:** Key Authority processing time
- **Statistical Analysis:** Collect averages across 100+ iterations, recording mean, variance, and outlier identification

**Step 6:** Ciphertext Size Analysis
For each encrypted payload, comprehensive size recording:
- Byte size of Paillier ciphertexts using `sys.getsizeof()` or `len(str(ciphertext))`
- Total network payload size per request via `Flask request.content_length`
- Comparative analysis of ciphertext size growth with increasing users/geofences

### 3.10 Ethical and Legal Considerations

#### 3.10.1 Privacy Protection Measures
The methodology incorporates comprehensive privacy safeguards:
- **Data Minimization:** Only encrypted intermediate values or Haversine components are transmitted; no raw location coordinates are stored
- **Operational Compliance:** System design aligns with NIST SP 800-207 (Zero Trust) principles by ensuring no single party maintains full control of sensitive information
- **Privacy-by-Design:** Proactive privacy protection embedded throughout system architecture

#### 3.10.2 Regulatory Compliance Framework
- **GDPR Article 25:** Privacy-by-design and privacy-by-default implementation
- **Data Protection Impact Assessment:** Comprehensive evaluation of privacy risks and mitigation strategies
- **Technical and Organizational Measures:** Cryptographic protection combined with access control and audit mechanisms

#### 3.10.3 Ethical Research Standards
- **Informed Consent:** Clear documentation of data processing purposes and methods
- **Transparency:** Open-source implementation enabling research reproducibility
- **Minimal Risk:** Use of synthetic data eliminates risks to actual individuals while maintaining research validity

This comprehensive methodological framework ensures systematic, reproducible evaluation of privacy-preserving geofencing systems while maintaining academic rigor and practical applicability for real-world deployment scenarios.