# Comprehensive Results Tables

## Performance Comparison Table (All Scales)

| Load Size | Paillier Latency (s) | Paillier Std Dev (s) | Paillier Throughput (req/s) | Paillier Accuracy (%) | CKKS Latency (s) | CKKS Std Dev (s) | CKKS Throughput (req/s) | CKKS Accuracy (%) | Latency Improvement (%) | Throughput Improvement (%) |
|-----------|----------------------|----------------------|-----------------------------|-----------------------|------------------|------------------|-------------------------|-------------------|-------------------------|----------------------------|
| 10 requests | 7.5760 | 3.6958 | 0.1440 | 100.00 | 0.5072 | 0.1570 | 1.9714 | 100.00 | 93.30 | 1269.11 |
| 100 requests | 61.1406 | 34.5141 | 0.0165 | 100.00 | 0.4595 | 0.0568 | 2.1761 | 100.00 | 99.25 | 13074.21 |
| 500 requests | 294.4010 | 168.8465 | 0.0034 | 100.00 | 0.4568 | 0.0298 | 2.1891 | 100.00 | 99.84 | 64218.06 |
| 1000 requests | 602.5867 | 346.9313 | 0.0017 | 100.00 | 0.4577 | 0.0270 | 2.1847 | 100.00 | 99.92 | 131414.09 |


## Resource Utilization Comparison (All Scales)

| Load Size | Paillier CPU (%) | Paillier RAM (MB) | Paillier Ciphertext (bytes) | Paillier Payload (bytes) | CKKS CPU (%) | CKKS RAM (MB) | CKKS Ciphertext (bytes) | CKKS Payload (bytes) | Size Ratio (CKKS/Paillier) |
|-----------|------------------|-------------------|-----------------------------|--------------------------|--------------|---------------|-------------------------|----------------------|----------------------------|
| 10 requests | 16.57 | -0.05 | 177 | 6599 | -0.17 | 7.89 | 324541 | 8525576 | 1833.6x |
| 100 requests | 22.51 | -0.92 | 177 | 6599 | 0.15 | 8.18 | 324550 | 8525585 | 1833.6x |
| 500 requests | 10.81 | -1.88 | 177 | 6599 | 1.13 | 8.15 | 324522 | 8525557 | 1833.5x |
| 1000 requests | 8.74 | -17.47 | 177 | 6599 | 1.70 | 8.29 | 324511 | 8525547 | 1833.4x |


## Detailed Statistical Analysis (All Scales)

| Scheme | Load Size | Mean Latency (s) | Std Dev Latency (s) | Median Latency (s) | Min Latency (s) | Max Latency (s) | Mean Encryption (s) | Std Encryption (s) | Throughput (req/s) | Accuracy | Precision | Recall | F1-Score |
|--------|-----------|------------------|---------------------|--------------------|-----------------|-----------------|---------------------|--------------------|--------------------|----------|-----------|--------|----------|
| Paillier | 10 requests | 7.576043 | 3.695831 | 8.608881 | 1.000000 | 15.694580 | 0.090917 | 0.287914 | 0.1440 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| CKKS | 10 requests | 0.507242 | 0.157042 | 0.454763 | 0.429243 | 1.000000 | 0.095037 | 0.286610 | 1.9714 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| Paillier | 100 requests | 61.140551 | 34.514077 | 61.642330 | 1.000000 | 122.389837 | 0.009909 | 0.099025 | 0.0165 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| CKKS | 100 requests | 0.459543 | 0.056778 | 0.450081 | 0.426340 | 1.000000 | 0.014219 | 0.098595 | 2.1761 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| Paillier | 500 requests | 294.401034 | 168.846487 | 294.188231 | 1.000000 | 590.956599 | 0.002005 | 0.044633 | 0.0034 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| CKKS | 500 requests | 0.456815 | 0.029806 | 0.451560 | 0.424505 | 1.000000 | 0.006294 | 0.044443 | 2.1891 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| Paillier | 1000 requests | 602.586744 | 346.931342 | 602.113457 | 1.000000 | 1255.993358 | 0.001010 | 0.031591 | 0.0017 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |
| CKKS | 1000 requests | 0.457734 | 0.026979 | 0.452618 | 0.425905 | 2.385770 | 0.005318 | 0.031429 | 2.1847 | 1.0000 | 1.0000 | 1.0000 | 1.0000 |


## Key Findings Summary

### Performance Improvements (CKKS vs Paillier)

**10 Requests:**
- Latency Improvement: 93.30%
- Throughput Improvement: 1269.11%
- CKKS Latency: 0.5072s vs Paillier: 7.5760s
- CKKS Throughput: 1.9714 req/s vs Paillier: 0.1440 req/s

**100 Requests:**
- Latency Improvement: 99.25%
- Throughput Improvement: 13074.21%
- CKKS Latency: 0.4595s vs Paillier: 61.1406s
- CKKS Throughput: 2.1761 req/s vs Paillier: 0.0165 req/s

**500 Requests:**
- Latency Improvement: 99.84%
- Throughput Improvement: 64218.06%
- CKKS Latency: 0.4568s vs Paillier: 294.4010s
- CKKS Throughput: 2.1891 req/s vs Paillier: 0.0034 req/s

**1000 Requests:**
- Latency Improvement: 99.92%
- Throughput Improvement: 131414.09%
- CKKS Latency: 0.4577s vs Paillier: 602.5867s
- CKKS Throughput: 2.1847 req/s vs Paillier: 0.0017 req/s

