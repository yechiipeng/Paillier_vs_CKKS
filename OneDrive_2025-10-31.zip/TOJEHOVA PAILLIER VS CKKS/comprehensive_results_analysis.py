#!/usr/bin/env python3
"""
Comprehensive Results Analysis for Privacy-Preserving Geofencing
Analyzes performance metrics from both Paillier and CKKS implementations
"""

import csv
import numpy as np
        # 1. Latency Comparison Chart
        load_sizes = []
        paillier_latencies = []
        ckks_latencies = []
        
        all_sizes = ['10', '100', '500', '1000']
        for size in all_sizes:pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import statistics
from collections import defaultdict
import json

class GeofencingResultsAnalyzer:
    def __init__(self):
        self.paillier_data = {}
        self.ckks_data = {}
        self.comparison_results = {}
        
    def load_data(self, base_path):
        """Load all CSV result files from both schemes"""
        base_path = Path(base_path)
        
        # Load Paillier results
        paillier_files = {
            '10': base_path / 'PAILLIER' / 'results.csv',
            '100': base_path / 'PAILLIER' / '100_requests_results.csv',
            '500': base_path / 'PAILLIER' / '500_requests_results.csv', 
            '1000': base_path / 'PAILLIER' / '1000_requests_results.csv'
        }
        
        # Load CKKS results
        ckks_files = {
            '10': base_path / 'CKKS' / '10_results_ckks.csv',
            '100': base_path / 'CKKS' / '100_results_ckks.csv',
            '500': base_path / 'CKKS' / '500_results_ckks.csv',
            '1000': base_path / 'CKKS' / '1000_results_ckks.csv'
        }
        
        # Load Paillier data
        for load_size, file_path in paillier_files.items():
            if file_path.exists():
                self.paillier_data[load_size] = pd.read_csv(file_path)
                print(f"Loaded Paillier {load_size} requests: {len(self.paillier_data[load_size])} records")
        
        # Load CKKS data  
        for load_size, file_path in ckks_files.items():
            if file_path.exists():
                self.ckks_data[load_size] = pd.read_csv(file_path)
                print(f"Loaded CKKS {load_size} requests: {len(self.ckks_data[load_size])} records")
    
    def calculate_metrics(self, df):
        """Calculate comprehensive metrics from dataframe"""
        metrics = {}
        
        # Convert string columns to appropriate types
        df['correct'] = df['correct'].astype(bool)
        df['total_time'] = pd.to_numeric(df['total_time'], errors='coerce')
        df['encryption_time'] = pd.to_numeric(df['encryption_time'], errors='coerce')
        if 'decryption_time' in df.columns:
            df['decryption_time'] = pd.to_numeric(df['decryption_time'], errors='coerce')
        if 'ciphertext_size' in df.columns:
            df['ciphertext_size'] = pd.to_numeric(df['ciphertext_size'], errors='coerce')
        if 'payload_size' in df.columns:
            df['payload_size'] = pd.to_numeric(df['payload_size'], errors='coerce')
        
        # Correctness Metrics
        total_requests = len(df)
        correct_predictions = df['correct'].sum()
        metrics['accuracy'] = correct_predictions / total_requests if total_requests > 0 else 0
        
        # Calculate precision, recall, F1 for "inside" predictions
        true_inside = df[df['plaintext_decision'] == 'inside']
        pred_inside = df[df['encrypted_decision'] == 'inside']
        
        if len(true_inside) > 0 and len(pred_inside) > 0:
            true_positives = len(df[(df['plaintext_decision'] == 'inside') & (df['encrypted_decision'] == 'inside')])
            false_positives = len(df[(df['plaintext_decision'] == 'outside') & (df['encrypted_decision'] == 'inside')])
            false_negatives = len(df[(df['plaintext_decision'] == 'inside') & (df['encrypted_decision'] == 'outside')])
            
            metrics['precision'] = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
            metrics['recall'] = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
            metrics['f1_score'] = 2 * (metrics['precision'] * metrics['recall']) / (metrics['precision'] + metrics['recall']) if (metrics['precision'] + metrics['recall']) > 0 else 0
        else:
            metrics['precision'] = metrics['recall'] = metrics['f1_score'] = 0
        
        # Performance Metrics
        metrics['avg_total_time'] = df['total_time'].mean()
        metrics['std_total_time'] = df['total_time'].std()
        metrics['median_total_time'] = df['total_time'].median()
        metrics['min_total_time'] = df['total_time'].min()
        metrics['max_total_time'] = df['total_time'].max()
        
        metrics['avg_encryption_time'] = df['encryption_time'].mean()
        metrics['std_encryption_time'] = df['encryption_time'].std()
        
        if 'decryption_time' in df.columns:
            metrics['avg_decryption_time'] = df['decryption_time'].mean()
            metrics['std_decryption_time'] = df['decryption_time'].std()
        
        # Calculate throughput (requests/second)
        total_time_sum = df['total_time'].sum()
        metrics['throughput'] = total_requests / total_time_sum if total_time_sum > 0 else 0
        
        # Resource Utilization Metrics
        if 'cpu_end' in df.columns and 'cpu_start' in df.columns:
            metrics['avg_cpu_usage'] = (df['cpu_end'] - df['cpu_start']).mean()
            metrics['max_cpu_usage'] = (df['cpu_end'] - df['cpu_start']).max()
        
        if 'ram_end' in df.columns and 'ram_start' in df.columns:
            metrics['avg_ram_usage'] = (df['ram_end'] - df['ram_start']).mean()
            metrics['max_ram_usage'] = (df['ram_end'] - df['ram_start']).max()
        
        # Communication Cost Metrics
        if 'ciphertext_size' in df.columns:
            metrics['avg_ciphertext_size'] = df['ciphertext_size'].mean()
            metrics['total_ciphertext_size'] = df['ciphertext_size'].sum()
        
        if 'payload_size' in df.columns:
            metrics['avg_payload_size'] = df['payload_size'].mean()
            metrics['total_payload_size'] = df['payload_size'].sum()
        
        return metrics
    
    def analyze_all_data(self):
        """Analyze all loaded data and generate comprehensive metrics"""
        results = {
            'paillier': {},
            'ckks': {}
        }
        
        # Analyze Paillier data
        for load_size, df in self.paillier_data.items():
            results['paillier'][load_size] = self.calculate_metrics(df)
            print(f"Analyzed Paillier {load_size} requests")
        
        # Analyze CKKS data
        for load_size, df in self.ckks_data.items():
            results['ckks'][load_size] = self.calculate_metrics(df)
            print(f"Analyzed CKKS {load_size} requests")
        
        self.comparison_results = results
        return results
    
    def generate_comparison_tables(self):
        """Generate comparison tables for academic presentation"""
        
        # Performance Comparison Table
        perf_table = []
        load_sizes = ['10', '100', '500', '1000']  # Common load sizes
        
        for load_size in load_sizes:
            row = {'Load Size': f"{load_size} requests"}
            
            if load_size in self.comparison_results['paillier']:
                paillier_metrics = self.comparison_results['paillier'][load_size]
                row['Paillier Avg Latency (s)'] = f"{paillier_metrics['avg_total_time']:.4f}"
                row['Paillier Throughput (req/s)'] = f"{paillier_metrics['throughput']:.2f}"
                row['Paillier Accuracy (%)'] = f"{paillier_metrics['accuracy']*100:.2f}"
            
            if load_size in self.comparison_results['ckks']:
                ckks_metrics = self.comparison_results['ckks'][load_size]
                row['CKKS Avg Latency (s)'] = f"{ckks_metrics['avg_total_time']:.4f}"
                row['CKKS Throughput (req/s)'] = f"{ckks_metrics['throughput']:.2f}"
                row['CKKS Accuracy (%)'] = f"{ckks_metrics['accuracy']*100:.2f}"
                
                # Calculate performance improvement
                if load_size in self.comparison_results['paillier']:
                    latency_improvement = ((paillier_metrics['avg_total_time'] - ckks_metrics['avg_total_time']) / paillier_metrics['avg_total_time']) * 100
                    throughput_improvement = ((ckks_metrics['throughput'] - paillier_metrics['throughput']) / paillier_metrics['throughput']) * 100
                    row['Latency Improvement (%)'] = f"{latency_improvement:.2f}"
                    row['Throughput Improvement (%)'] = f"{throughput_improvement:.2f}"
            
            perf_table.append(row)
        
        # Resource Utilization Table
        resource_table = []
        for load_size in load_sizes:
            row = {'Load Size': f"{load_size} requests"}
            
            if load_size in self.comparison_results['paillier']:
                paillier_metrics = self.comparison_results['paillier'][load_size]
                row['Paillier Avg CPU (%)'] = f"{paillier_metrics.get('avg_cpu_usage', 0):.2f}"
                row['Paillier Avg RAM (MB)'] = f"{paillier_metrics.get('avg_ram_usage', 0):.2f}"
                row['Paillier Ciphertext Size (bytes)'] = f"{paillier_metrics.get('avg_ciphertext_size', 0):.0f}"
            
            if load_size in self.comparison_results['ckks']:
                ckks_metrics = self.comparison_results['ckks'][load_size]
                row['CKKS Avg CPU (%)'] = f"{ckks_metrics.get('avg_cpu_usage', 0):.2f}"
                row['CKKS Avg RAM (MB)'] = f"{ckks_metrics.get('avg_ram_usage', 0):.2f}"
                row['CKKS Ciphertext Size (bytes)'] = f"{ckks_metrics.get('avg_ciphertext_size', 0):.0f}"
            
            resource_table.append(row)
        
        return perf_table, resource_table
    
    def create_visualizations(self, output_dir):
        """Create comprehensive visualizations"""
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
        
        # Set style for academic papers
        plt.style.use('seaborn-v0_8-whitegrid')
        sns.set_palette("husl")
        
        # 1. Latency Comparison Chart
        load_sizes = []
        paillier_latencies = []
        ckks_latencies = []
        
        common_sizes = ['10', '100', '500', '1000']
        for size in common_sizes:
            if size in self.comparison_results['paillier'] and size in self.comparison_results['ckks']:
                load_sizes.append(int(size))
                paillier_latencies.append(self.comparison_results['paillier'][size]['avg_total_time'])
                ckks_latencies.append(self.comparison_results['ckks'][size]['avg_total_time'])
        
        fig, ax = plt.subplots(figsize=(10, 6))
        x = np.arange(len(load_sizes))
        width = 0.35
        
        bars1 = ax.bar(x - width/2, paillier_latencies, width, label='Paillier', alpha=0.8)
        bars2 = ax.bar(x + width/2, ckks_latencies, width, label='CKKS', alpha=0.8)
        
        ax.set_xlabel('Number of Requests')
        ax.set_ylabel('Average Latency (seconds)')
        ax.set_title('Performance Comparison: Average Latency by Load Size')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'latency_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. Throughput Comparison Chart
        paillier_throughput = []
        ckks_throughput = []
        
        for size in common_sizes:
            if size in self.comparison_results['paillier'] and size in self.comparison_results['ckks']:
                paillier_throughput.append(self.comparison_results['paillier'][size]['throughput'])
                ckks_throughput.append(self.comparison_results['ckks'][size]['throughput'])
        
        fig, ax = plt.subplots(figsize=(10, 6))
        bars1 = ax.bar(x - width/2, paillier_throughput, width, label='Paillier', alpha=0.8)
        bars2 = ax.bar(x + width/2, ckks_throughput, width, label='CKKS', alpha=0.8)
        
        ax.set_xlabel('Number of Requests')
        ax.set_ylabel('Throughput (requests/second)')
        ax.set_title('Performance Comparison: Throughput by Load Size')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'throughput_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. Ciphertext Size Comparison
        paillier_sizes = []
        ckks_sizes = []
        
        for size in common_sizes:
            if size in self.comparison_results['paillier'] and size in self.comparison_results['ckks']:
                paillier_sizes.append(self.comparison_results['paillier'][size].get('avg_ciphertext_size', 0))
                ckks_sizes.append(self.comparison_results['ckks'][size].get('avg_ciphertext_size', 0))
        
        fig, ax = plt.subplots(figsize=(10, 6))
        bars1 = ax.bar(x - width/2, paillier_sizes, width, label='Paillier', alpha=0.8)
        bars2 = ax.bar(x + width/2, ckks_sizes, width, label='CKKS', alpha=0.8)
        
        ax.set_xlabel('Number of Requests')
        ax.set_ylabel('Average Ciphertext Size (bytes)')
        ax.set_title('Communication Cost: Ciphertext Size Comparison')
        ax.set_xticks(x)
        ax.set_xticklabels(load_sizes)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'ciphertext_size_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 4. Scalability Analysis
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        
        # Latency vs Load Size
        ax1.plot(load_sizes, paillier_latencies, 'o-', label='Paillier', linewidth=2, markersize=8)
        ax1.plot(load_sizes, ckks_latencies, 's-', label='CKKS', linewidth=2, markersize=8)
        ax1.set_xlabel('Load Size (requests)')
        ax1.set_ylabel('Average Latency (s)')
        ax1.set_title('Scalability: Latency Trends')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Throughput vs Load Size
        ax2.plot(load_sizes, paillier_throughput, 'o-', label='Paillier', linewidth=2, markersize=8)
        ax2.plot(load_sizes, ckks_throughput, 's-', label='CKKS', linewidth=2, markersize=8)
        ax2.set_xlabel('Load Size (requests)')
        ax2.set_ylabel('Throughput (req/s)')
        ax2.set_title('Scalability: Throughput Trends')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Resource Usage Comparison
        paillier_cpu = [self.comparison_results['paillier'][size].get('avg_cpu_usage', 0) for size in common_sizes if size in self.comparison_results['paillier']]
        ckks_cpu = [self.comparison_results['ckks'][size].get('avg_cpu_usage', 0) for size in common_sizes if size in self.comparison_results['ckks']]
        
        ax3.plot(load_sizes, paillier_cpu, 'o-', label='Paillier CPU', linewidth=2, markersize=8)
        ax3.plot(load_sizes, ckks_cpu, 's-', label='CKKS CPU', linewidth=2, markersize=8)
        ax3.set_xlabel('Load Size (requests)')
        ax3.set_ylabel('Average CPU Usage (%)')
        ax3.set_title('Resource Utilization: CPU Usage')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # Ciphertext Size Trends
        ax4.plot(load_sizes, paillier_sizes, 'o-', label='Paillier', linewidth=2, markersize=8)
        ax4.plot(load_sizes, ckks_sizes, 's-', label='CKKS', linewidth=2, markersize=8)
        ax4.set_xlabel('Load Size (requests)')
        ax4.set_ylabel('Average Ciphertext Size (bytes)')
        ax4.set_title('Communication Cost: Size Trends')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_dir / 'scalability_analysis.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Visualizations saved to {output_dir}")
    
    def export_results(self, output_file):
        """Export comprehensive results to JSON"""
        with open(output_file, 'w') as f:
            json.dump(self.comparison_results, f, indent=2)
        print(f"Results exported to {output_file}")

def main():
    analyzer = GeofencingResultsAnalyzer()
    base_path = r"C:\Users\nicol\Downloads\TOJEHOVA PAILLIER VS CKKS"
    
    # Load and analyze data
    analyzer.load_data(base_path)
    results = analyzer.analyze_all_data()
    
    # Generate comparison tables
    perf_table, resource_table = analyzer.generate_comparison_tables()
    
    # Print summary results
    print("\n=== PERFORMANCE COMPARISON TABLE ===")
    for row in perf_table:
        print(row)
    
    print("\n=== RESOURCE UTILIZATION TABLE ===")
    for row in resource_table:
        print(row)
    
    # Create visualizations
    analyzer.create_visualizations(base_path)
    
    # Export detailed results
    analyzer.export_results(Path(base_path) / 'comprehensive_results.json')
    
    print("\nAnalysis complete!")

if __name__ == "__main__":
    main()